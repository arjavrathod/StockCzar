//
//  LoginViewModel.swift
//  StockCzar (iOS)
//
//  Created by Rathod Arjav on 13/08/22.
//
import Firebase
import FirebaseAuth
import Foundation
import FirebaseFirestore
class loginViewModel : ObservableObject{
    @Published var username = ""
    @Published var password = ""
    @Published var email = ""
    @Published var error = ""
    @Published var signInOrCreateAccount = false
    @Published var goNext = false
    
    
    func createUser(){
        Auth.auth().createUser(withEmail: email, password: password, completion: { (result, error) in
            if(error != nil){
                self.error = error!.localizedDescription
            }
            else{
                
                self.goNext = true
            }
        })
    }
    func login(){
        Auth.auth().signIn(withEmail: email, password: password, completion:  { (result, error) in
            if(error != nil){
                self.error = error!.localizedDescription
                
            }
            else{
                
                self.goNext = true
            }
        })
    }
}
