//
//  ViewModel.swift
//  StockCzar (iOS)
//
//  Created by Rathod Arjav on 13/08/22.
//

import Foundation
import MapKit

class mainViewModel : ObservableObject{
    @Published var crypto = datas(data: [])
    @Published var cryptoIsLoaded = false
    var universityLocation = CLLocationCoordinate2D(
        latitude: 43.013414,
        longitude: -81.199466)
    
    
    func getCoin() {
        guard let url = URL(string: "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest?start=1&limit=5000&convert=USD&CMC_PRO_API_KEY=8e85e2cf-f520-4f1e-9cc8-cab40c41fb1d") else { fatalError("Missing URL") }

        let urlRequest = URLRequest(url: url)

        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if let error = error {
                print("Request error: ", error)
                return
            }

            guard let response = response as? HTTPURLResponse else { return }

            if response.statusCode == 200 {
                guard let data = data else { return }
                
                DispatchQueue.main.async {
                    do {
                        let decodedUsers = try JSONDecoder().decode(datas.self, from: data)
                        self.crypto = decodedUsers
                        self.cryptoIsLoaded = true
                    } catch let error {
                        print("Error decoding: ", error)
                    }
                }
            }
        }

        dataTask.resume()
    }
    
}
