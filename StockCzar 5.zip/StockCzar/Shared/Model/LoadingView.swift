//
//  LoadingView.swift
//  StockCzar (iOS)
//
//  Created by Rathod Arjav on 13/08/22.
//

import SwiftUI

struct LoadingView: View {
    @State var angle = Angle(degrees: 0)
    @State var rotationEnded = false
    @Binding var goNext : Bool
    var body: some View {
        ZStack{
            VStack{
                
                Image("bg").resizable().scaledToFill().opacity(0.2).background(.black.opacity(0.7))
                
            }.frame(width: UIScreen.main.bounds.width).clipped().ignoresSafeArea()
            VStack{
                Spacer()
                if(!rotationEnded){
                Image("app_icon").resizable().scaledToFit().frame(width: 150, height: 150).rotationEffect(angle).onAppear{
                    for i in 1...20{
                        DispatchQueue.main.asyncAfter(deadline: .now() + (0.05 * Double(i)) + 1 ){
                            withAnimation{
                        angle.degrees += 360/20
                            }
                        }
                        
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + (0.05 * 22) + 1.2 ){
                        withAnimation{
                            rotationEnded = true
                        }
                    }
                }
                }
                else{
                    VStack(spacing: 0){
                    Image("icon_is").resizable().scaledToFit().frame(width: 100, height: 100)
                        Text("StockCzar").font(.custom(SansPro.kaushan, size: 30)).foregroundColor(.white)
                    }.onAppear{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1 ){
                            withAnimation{
                                goNext.toggle()
                            }
                        }
                    }
                }
                
                Spacer()
                Spacer()
                Spacer()
            }
        }
    }
}

struct LoadingView_Previews: PreviewProvider {
    static var previews: some View {
        LoadingView(goNext: .constant(false))
    }
}
