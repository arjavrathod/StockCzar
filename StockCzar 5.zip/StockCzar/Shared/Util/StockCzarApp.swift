//
//  StockCzarApp.swift
//  Shared
//
//  Created by Rathod Arjav on 13/08/22.
//

import SwiftUI
import Firebase
@main
struct StockCzarApp: App {
    init(){
        FirebaseApp.configure()
    }
    @State var goNext = false
    var body: some Scene {
        WindowGroup {
            if(goNext){
            ContentView().navigationBarHidden(true)
            }
            else{
                LoadingView(goNext: $goNext)
            }
        }
    }
}
