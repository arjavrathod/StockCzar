//
//  class.swift
//  StockCzar (iOS)
//
//  Created by Rathod Arjav on 13/08/22.
//

import Foundation
import SwiftUI
struct datas: Decodable{
    struct status : Decodable{
        var timestamp : String?
        var errorcode : Int?
        var errorMessage : String?
        var elapsed : Int?
        var credit_count : Int?
        var notice : String?
        var totalCount : Int?
    }
    var data : [coin]
}

struct coin :Identifiable, Decodable {
    var id :  Int?
    var name :  String?
    var symbol :  String?
    var slug :  String?
    var num_market_pairs :  Int?
    var date_added :  String?
    var tags :  [String]?
    var max_supply :  Float?
    var circulating_supply :  Float?
    var total_supply :  Float?
    var cmc_rank :  Int?
    var last_updated :  String?
    var quote : qoutes
}
struct qoutes : Decodable{
    var USD : qouteDetail
}
struct qouteDetail : Decodable{
    var price : Float?
    var volume_24h : Float?
    var volume_change_24h : Float?
    var percent_change_1h : Float?
    var percent_change_24h  : Float?
    var percent_change_7d : Float?
    var percent_change_30d : Float?
    var percent_change_60d  : Float?
    var percent_change_90d  : Float?
    var market_cap : Float?
    var market_cap_dominance : Float?
    var fully_diluted_market_cap : Float?
    var last_updated :  String?
}

