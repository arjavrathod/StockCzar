//
//  MapUtil.swift
//  StockCzar (iOS)
//
//  Created by Rathod Arjav on 13/08/22.
//

import Foundation
import SwiftUI
import MapKit
struct Place: Identifiable {
    let id = UUID()
    var name: String
    var coordinate: CLLocationCoordinate2D
}

struct UniversityMapView: View {
    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(
        latitude: 43.013414,
        longitude: -81.199466), span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
    private let manager = CLLocationManager()
    var university =
    Place(name: "", coordinate:  CLLocationCoordinate2D(
        latitude: 43.013414,
        longitude: -81.199466))
    init(){
        // func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let manager = CLLocationManager()
        if manager.authorizationStatus == .authorizedWhenInUse{
            manager.desiredAccuracy = kCLLocationAccuracyBest
            manager.requestWhenInUseAuthorization()
            manager.startUpdatingLocation()
        } else {
            
            manager.requestWhenInUseAuthorization()
        }
        // }
    }
    var body: some View {
        
        Map(coordinateRegion: $region, showsUserLocation: true,
            annotationItems: [university]
        ) { place in
            MapAnnotation(coordinate: place.coordinate) {
                PlaceAnnotationView()
            }
        }.overlay(VStack{
            Spacer()
            HStack{
                Spacer()
                Button(action: {
                    if let location = manager.location {
                        withAnimation{
                            self.region = MKCoordinateRegion(center: location.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5))
                        }
                    }
                }){
                    Image(systemName: "location.north.fill").resizable().scaledToFit().padding(10).frame(width: 40, height: 40).background(.white).cornerRadius(10).shadow(radius: 5)
                }.padding()
            }
        })
    }
}
struct PlaceAnnotationView: View {
    var body: some View {
        VStack(spacing: 0) {
            Image("fanshawe").resizable().scaledToFit().frame(width: 30)
        }
    }
}

