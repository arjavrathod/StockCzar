//
//  MainView.swift
//  StockCzar (iOS)
//
//  Created by Rathod Arjav on 13/08/22.
//

import SwiftUI
import FirebaseAuth

struct MainView: View {
    @ObservedObject var model = mainViewModel()
    @State var showMenu = false
    @State var curve = CGPoint(x: UIScreen.main.bounds.width/2, y: UIScreen.main.bounds.width * 0.4 )
    @State var selectedMenu = 0
    @State var menuSelected = false
    var body: some View {
        ZStack{
            ZStack{
                VStack{
                    
                    Image("bg").resizable().scaledToFill().opacity(0.2).background(.black.opacity(0.7))
                    
                }.frame(width: UIScreen.main.bounds.width).clipped().ignoresSafeArea()
                VStack{
                    HStack{
                        Button(action: {
                            withAnimation{
                                showMenu.toggle()
                            }
                        }){
                            Image(systemName: "line.3.horizontal").resizable().scaledToFit().frame(width: 20, height: 20).foregroundColor(.white).padding().background(Color.black.opacity(0.3)).cornerRadius(180)
                        }
                        Spacer()
                    }.padding(.leading)
                    Spacer()
                }
            }
            VStack{
                Spacer()
                Image("icon_is").resizable().scaledToFit().padding(80)
                Spacer()
                HStack{
                    NavigationLink(destination: MarketView().environmentObject(model).navigationBarHidden(true)){
                        HStack{
                            Spacer()
                            VStack{
                                Text("Crypto Market").font(.custom(SansPro.semibold, size: 16))
                                Image("ic_market")
                            }.padding()
                            Spacer()
                        }.background(Color.black.opacity(0.4)).cornerRadius(10)
                    }.padding([.leading, .top] , 16).padding([.trailing,.bottom], 8)
                    
                    NavigationLink(destination: MapView().environmentObject(model).navigationBarHidden(true)){
                        HStack{
                            Spacer()
                            VStack{
                                Text("Info Map").font(.custom(SansPro.semibold, size: 16))
                                Image("ic_info_map")
                            }.padding()
                            Spacer()
                        }.background(Color.black.opacity(0.4)).cornerRadius(10)
                    }.padding([.trailing, .top] , 16).padding([.leading,.bottom], 8)
                }
                HStack{
                    NavigationLink(destination: TeamView().environmentObject(model).navigationBarHidden(true)){
                        HStack{
                            Spacer()
                            VStack{
                                Text("Team Members").font(.custom(SansPro.semibold, size: 16))
                                Image("ic_team")
                            }.padding()
                            Spacer()
                        }.background(Color.black.opacity(0.4)).cornerRadius(10)
                    }.padding([.leading, .top] , 16).padding([.trailing,.bottom], 8)
                }
            }.foregroundColor(.white)
            
            if(showMenu){
                VStack{
                    Spacer()
                    HStack{
                        Spacer()
                    }
                }.background(
                    Color.black.opacity(0.4)).ignoresSafeArea().onTapGesture {
                        withAnimation{
                            showMenu.toggle()
                        }
                    }
                
            }
            VStack{
                ZStack{
                    Path{ path in
                        path.move(to: CGPoint(x: 0, y: 0))
                        path.addLine(to: CGPoint(x: UIScreen.main.bounds.width/2 - 60, y: 0))
                        path.addCurve(to: CGPoint(x: UIScreen.main.bounds.width/2 - 60, y: UIScreen.main.bounds.height), control1: curve, control2: curve)
                        
                        path.addLine(to: CGPoint(x: 0, y: UIScreen.main.bounds.height))
                        path.addLine(to: CGPoint(x: 0, y: 0))
                    }.fill(.white)
                    Path{ path in
                        path.move(to: CGPoint(x: 0, y: 0))
                        path.addLine(to: CGPoint(x: UIScreen.main.bounds.width/2 - 60, y: 0))
                        path.addCurve(to: CGPoint(x: UIScreen.main.bounds.width/2 - 60, y: UIScreen.main.bounds.height), control1: curve, control2: curve)
                        
                        path.addLine(to: CGPoint(x: 0, y: UIScreen.main.bounds.height))
                        path.addLine(to: CGPoint(x: 0, y: 0))
                    }.fill(.black.opacity(0.8)).overlay(HStack{
                        VStack(alignment: .leading){
                            Spacer()
                            Spacer()
                            Spacer()
                            VStack{
                                Image("icon_is").resizable().scaledToFit().padding(5).frame(width: UIScreen.main.bounds.width * 0.3).overlay(Circle().stroke(lineWidth: 3).foregroundColor(.white))
                                Text("StockCzar")
                            }.onTapGesture{
                                withAnimation(.easeInOut(duration: 1)){
                                    curve.y = UIScreen.main.bounds.height * 0.35
                                }
                            }
                            VStack(alignment: .leading){
                                Button(action: {
                                    withAnimation(.easeInOut(duration: 1)){
                                        curve.y = UIScreen.main.bounds.height * 0.5
                                    }
                                    selectedMenu = 1
                                    menuSelected = true
                                    
                                }){
                                    HStack{
                                        Image("ic_home").resizable().scaledToFit().frame(width: 18, height: 18)
                                        Text("Home").font(.custom(SansPro.regular, size: 15))
                                    }}.padding(.vertical, 10)
                                
                                Button(action: {
                                    withAnimation(.easeInOut(duration: 1)){
                                        curve.y = UIScreen.main.bounds.height * 0.6
                                    }
                                    selectedMenu = 2
                                    menuSelected = true
                                    
                                }){
                                    HStack{
                                        Image("ic_info_map").resizable().scaledToFit().frame(width: 18, height: 18)
                                        Text("Info Map").font(.custom(SansPro.regular, size: 15))
                                    }
                                }.padding(.vertical, 10)
                                
                                Button(action: {
                                    withAnimation(.easeInOut(duration: 7)){
                                        curve.y = UIScreen.main.bounds.height * 0.6
                                    }
                                    menuSelected = true
                                    selectedMenu = 3
                                }){
                                    HStack{
                                        Image("ic_team").resizable().scaledToFit().frame(width: 18, height: 18)
                                        Text("Team Members").font(.custom(SansPro.regular, size: 15))
                                    }
                                }.padding(.vertical, 10)
                                Button(action: {
                                    do{
                                     try Auth.auth().signOut()
                                    }
                                    catch{
                                        print(error.localizedDescription)
                                    }
                                    menuSelected = true
                                    selectedMenu = 4
                                }){
                                HStack{
                                    Image("ic_logout").resizable().scaledToFit().frame(width: 18, height: 18)
                                    Text("Log Out").font(.custom(SansPro.regular, size: 15))
                                }
                                }.padding(.vertical, 10)
                            }
                            VStack{
                            if(selectedMenu == 1){
                                NavigationLink(destination: MarketView().environmentObject(model).navigationBarHidden(true), isActive: $menuSelected){
                                    EmptyView()
                                }
                            }
                            if(selectedMenu == 2){
                                NavigationLink(destination: MapView().environmentObject(model).navigationBarHidden(true), isActive: $menuSelected){
                                    EmptyView()
                                }
                            }
                            if(selectedMenu == 3){
                                NavigationLink(destination: TeamView().environmentObject(model).navigationBarHidden(true), isActive: $menuSelected){
                                    EmptyView()
                                }
                            }
                            if(selectedMenu == 4){
                                NavigationLink(destination: SignIn().environmentObject(loginViewModel()).navigationBarHidden(true), isActive: $menuSelected){
                                    EmptyView()
                                }
                            }
                            }
                            Spacer()
                            Spacer()
                        }.foregroundColor(.white).frame(width: UIScreen.main.bounds.width * 0.35)
                        Spacer()
                    })
                }
                Spacer()
            }.edgesIgnoringSafeArea(.all).offset(x: showMenu ? 0 : -1 * UIScreen.main.bounds.width)
            
        }
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}

