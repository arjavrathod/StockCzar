//
//  MapView.swift
//  StockCzar (iOS)
//
//  Created by Rathod Arjav on 13/08/22.
//

import SwiftUI

struct MapView: View {
    @Environment(\.presentationMode) var presentation
    @EnvironmentObject var model : mainViewModel
    var body: some View {
        ZStack{
            
            VStack(spacing: 0){
            HStack{
                Button(action: {
                    presentation.wrappedValue.dismiss()
                }){
                Image(systemName: "chevron.left")
                }
                Spacer()
                Text("Map Info").font(.custom(SansPro.bold, size: 16))
                Spacer()
            }.padding().foregroundColor(.white).background(Color.black.opacity(0.8))
            
            UniversityMapView()
            HStack{
                Image("fanshawe").resizable().scaledToFit().frame(width: 50, height: 50)
                
                    Spacer()
                VStack(alignment: .leading){
                    Text("1001 Fanshawe College").font(.custom(SansPro.semibold, size: 18))
                    Text("1001 Fanshawe College Blvd, London, ON N5V 2A5").font(.custom(SansPro.regular, size: 16))
                    
                }.foregroundColor(.white)
                
                    Spacer()
                Button(action: {
                    let url = URL(string: "maps://?saddr=&daddr=\(43.013414),\(-81.199466)")
                    if UIApplication.shared.canOpenURL(url!) {
                        UIApplication.shared.open(url!, options: [:], completionHandler: nil)
                    }
                }){
                VStack{
                    Image(systemName: "location.north.fill").resizable().scaledToFit().padding([.top, .horizontal]).frame(width: 50, height: 50)
                Text("Navigate")
                }.foregroundColor(.white)
                }
            }.padding([.horizontal,.top], 10).background(Color.black.opacity(0.8))
        }
        }
    }
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView().environmentObject(mainViewModel())
    }
}
