//
//  TeamView.swift
//  StockCzar (iOS)
//
//  Created by Rathod Arjav on 13/08/22.
//

import SwiftUI

struct TeamView: View {
    @Environment(\.presentationMode) var presentation
    @EnvironmentObject var model : mainViewModel
    var body: some View {
        VStack{
            HStack{
                Button(action: {
                    presentation.wrappedValue.dismiss()
                }){
                Image(systemName: "chevron.left")
                }
                Spacer()
                Text("Team Members").font(.custom(SansPro.bold, size: 16))
                Spacer()
            }.padding().foregroundColor(.white).background(Color.black.opacity(0.8)).padding(.bottom)
            HStack(spacing: 20){
                Image("arjav").resizable().scaledToFit().padding(5).frame(width: 80, height: 80, alignment: .center).background(.white).clipped().cornerRadius(360).shadow(radius: 1)
                VStack(alignment: .leading, spacing: 5){
                    Text("ARJAV RATHOD").font(.custom(SansPro.semibold, size: 18))
                    Text("Team Leader, Coder, Analyst,  Paperwork").font(.custom(SansPro.light, size: 12))
                }
                Spacer()
            }.overlay(HStack{
                Spacer()
                VStack{
                    Image("team_lead").resizable().scaledToFit().frame(width: 40, height: 40)
                    Spacer()
                }
            }).padding(.horizontal, 10)
            Spacer()
        }
    }
}

struct TeamView_Previews: PreviewProvider {
    static var previews: some View {
        TeamView().environmentObject(mainViewModel())
    }
}
