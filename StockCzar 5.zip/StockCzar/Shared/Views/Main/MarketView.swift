//
//  MarketView.swift
//  StockCzar (iOS)
//
//  Created by Rathod Arjav on 13/08/22.
//

import SwiftUI

struct MarketView: View {
    @Environment(\.presentationMode) var presentation
    @EnvironmentObject var model : mainViewModel
    @State var searchBar = ""
    @State var picker = ["Sort By Name", "Sort By 24h Change", "Sort By Market Cap", "Sort By 24h Volume"]
    @State var sort = ""
    @State var pressSortButton = false
    var topView : some View{
        HStack{
            Button(action: {
                presentation.wrappedValue.dismiss()
            }){
            Image(systemName: "chevron.left")
            }
            Spacer()
            Text("Crypto Market").font(.custom(SansPro.bold, size: 16))
            Spacer()
            Button(action: {
                withAnimation{
                    pressSortButton.toggle()
                }
            }){
                Image(systemName: "ellipsis").rotationEffect(Angle(degrees: 90))
            }
        }.padding().background(Color.black.opacity(0.8)).foregroundColor(.white)
        
    }
    var search  : some View{
        HStack{
            TextField("Enter name or Symbol", text: $searchBar).padding(10).background(Color.white).cornerRadius(10).shadow(radius: 5)
        }.padding(.horizontal)
    }
    var listHeader : some View{
        HStack{
            HStack{
                Text("Name").font(.custom(SansPro.semibold, size: 12))
            
                Spacer()
            }.frame(width: UIScreen.main.bounds.width / 3.4)
            Spacer()
            VStack{
                Text("Price USD").font(.custom(SansPro.semibold, size: 12))
                Text("24h Change").font(.custom(SansPro.semibold, size: 12))
            }.frame(width: UIScreen.main.bounds.width / 3.4)
            Spacer()
            HStack{
                Spacer()
            VStack(alignment: .trailing){
                Text("Market Cap").font(.custom(SansPro.semibold, size: 12))
                Text("24h Volume").font(.custom(SansPro.semibold, size: 12))
            }
            }.frame(width: UIScreen.main.bounds.width / 3.4)
            
        }.padding(.horizontal, 5).padding(.vertical, 10).foregroundColor(.white).background(Color.black.opacity(0.8))
   
    }
    var body: some View {
        ZStack{
        VStack{
            topView
            if(!model.cryptoIsLoaded){
                Spacer()
                ProgressView().onAppear{
                    if(model.crypto.data.isEmpty){
                    model.getCoin()
                    }
                }
                Spacer()
            }
            
            else{
                search
               listHeader
                ScrollView{
                
                    
                    
                    LazyVStack(alignment: .leading){
                        ForEach(model.crypto.data){ cr in
                            if(cr.name?.lowercased().contains(searchBar.lowercased()) ?? true || cr.symbol?.lowercased().contains(searchBar.lowercased()) ?? true || searchBar.isEmpty){
                            singleCell(coin: cr)
                            Divider()
                            }
                            
                        }
                    }
                    
                
            }
            }
        }
            if(pressSortButton){
                VStack{
                    Spacer()
                    HStack{
                        Spacer()
                    }
                }.background(Color.black.opacity(0.1)).onTapGesture {
                    withAnimation{
                    pressSortButton.toggle()
                    }
                }
                
            }
            VStack{
                Spacer()
                VStack{
                    ForEach(picker, id: \.self){ i in
                        Button(action: {
                            withAnimation{
                            if(i == "Sort By Name"){
                                model.crypto.data = model.crypto.data.sorted(by: {$0.name ?? "" < $1.name ?? ""})
                            }
                            else if(i == "Sort By 24h Change"){
                                model.crypto.data = model.crypto.data.sorted(by: {$0.quote.USD.percent_change_24h ?? 0 > $1.quote.USD.percent_change_24h ?? 0})
                            }
                            else if(i == "Sort By Market Cap"){
                                model.crypto.data = model.crypto.data.sorted(by: {$0.quote.USD.market_cap ?? 0 > $1.quote.USD.market_cap ?? 0})
                            }
                            else if(i == "Sort By Market Cap"){
                                model.crypto.data = model.crypto.data.sorted(by: {$0.quote.USD.market_cap ?? 0 > $1.quote.USD.market_cap ?? 0})
                            }
                            else if(i == "Sort By 24h Volume"){
                                model.crypto.data = model.crypto.data.sorted(by: {$0.quote.USD.volume_24h ?? 0 > $1.quote.USD.volume_24h ?? 0})
                            }
                            pressSortButton.toggle()
                            }
                        }){
                        HStack{
                            Spacer()
                            Text(i)
                            Spacer()
                        }.padding()
                            
                        }
                        Divider()
                    }
                }.background(Color.white)
            }.offset(y: (pressSortButton) ? 0 : UIScreen.main.bounds.height)
        }
    }
}
struct singleCell : View{
    var coin : coin
    var body: some View{
        HStack{
            HStack{
                checkImage(name: coin.symbol?.lowercased() ?? "")
            VStack(alignment: .leading){
                Text(coin.name ?? "error").font(.custom(SansPro.regular, size: 12))
                Text(coin.symbol ?? "error").font(.custom(SansPro.regular, size: 12))
            }
                Spacer()
            }.frame(width: UIScreen.main.bounds.width / 3.4)
            Spacer()
            VStack{
                Text("$\(coin.quote.USD.price ?? 0, specifier: "%.8f")").font(.custom(SansPro.regular, size: 12))
                Text("\(coin.quote.USD.percent_change_24h ?? 0, specifier: "%.8f")%").font(.custom(SansPro.regular, size: 12))
            }.frame(width: UIScreen.main.bounds.width / 3.4)
            Spacer()
            HStack{
                Spacer()
            VStack(alignment: .trailing){
                Text("$\(coin.quote.USD.market_cap ?? 0, specifier: "%.0f")").font(.custom(SansPro.regular, size: 12))
                Text("$\(coin.quote.USD.volume_24h ?? 0, specifier: "%.0f")").font(.custom(SansPro.regular, size: 12))
            }
            }.frame(width: UIScreen.main.bounds.width / 3.4)
            
        }.padding(.horizontal, 5)
    }
}

struct checkImage : View{
    var name : String
    var body: some View{
        VStack{
            if(UIImage(named:name) != nil){
            Image(name).resizable().scaledToFit().frame(width: 40, height: 40)
            }
            else{
                Image("app_icon").resizable().scaledToFit().frame(width: 40, height: 40)
            }
        }
    }
}
struct MarketView_Previews: PreviewProvider {
    static var previews: some View {
        MarketView().environmentObject(mainViewModel())
    }
}
