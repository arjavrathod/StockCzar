//
//  SignIn.swift
//  StockCzar
//
//  Created by Rathod Arjav on 13/08/22.
//

import SwiftUI

struct SignIn: View {
    @EnvironmentObject var model : loginViewModel
    var signIn : some View{
        VStack{
            Spacer()
            Image("icon_is").resizable().scaledToFit().frame(height: 140).padding(.top, 8).padding(.bottom, 32)
            Image("sign_in").resizable().scaledToFit().frame(height: 30).padding(.bottom, 16)
            HStack{
                Image("icon_person").resizable().scaledToFit().frame(height: 30)
                TextField("Email", text: $model.email).font(.custom(SansPro.regular, size: 16)).frame(height: 48)
            }.background(Color.gray).frame(width: 300,height: 48).padding(.bottom, 8)
            HStack{
                Image("icon_password").resizable().scaledToFit().frame(height: 30)
                SecureField("Password", text: $model.password).frame(height: 48).font(.custom(SansPro.regular, size: 16))
            }.background(Color.gray).frame(width: 300,height: 48).padding(.bottom, 8)
            Button(action: {
                model.login()
            }){
                HStack{
                    Spacer()
                    Text("Sign IN").font(.custom(SansPro.bold, size: 16)).textCase(.uppercase).foregroundColor(.white)
                    Spacer()
                }.frame(width: 300,height: 48).background(LinearGradient(colors: [Color(hex: "0575E6"), Color(hex: "69f8e4")], startPoint: .trailing, endPoint: .leading))
            }.padding(.bottom, 8).padding(.top, 16)
            Spacer().frame(height: 51)
            HStack{
                Text("Don't have an account").font(.custom(SansPro.semibold, size: 16))
                Button(action: {
                    withAnimation{
                        model.signInOrCreateAccount.toggle()
                    }
                }){
                    Text("Register Here!").font(.custom(SansPro.semibold, size: 16))
                }
            }
        }
    }
    var signUp : some View{
        VStack{
            Spacer()
            
            Image("icon_is").resizable().scaledToFit().frame(height: 140).padding(.top, 8).padding(.bottom, 32)
            Image("joinus_text").resizable().scaledToFit().frame(height: 30).padding(.bottom, 16)
            HStack{
                Image("icon_person").resizable().scaledToFit().frame(height: 30)
                TextField("Username", text: $model.username).font(.custom(SansPro.regular, size: 16)).frame(height: 48)
            }.background(Color.gray).frame(width: 300,height: 48).padding(.bottom, 8)
            HStack{
                Image("icon_mail").resizable().scaledToFit().frame(height: 30)
                TextField("Email", text: $model.email).font(.custom(SansPro.regular, size: 16)).frame(height: 48)
            }.background(Color.gray).frame(width: 300,height: 48).padding(.bottom, 8)
            HStack{
                Image("icon_password").resizable().scaledToFit().frame(height: 30)
                SecureField("Password", text: $model.password).font(.custom(SansPro.regular, size: 16)).frame(height: 48)
            }.background(Color.gray).frame(width: 300,height: 48).padding(.bottom, 8)
            Button(action: {
                model.createUser()
            }){
                HStack{
                    Spacer()
                    Text("Sign Up").textCase(.uppercase).font(.custom(SansPro.bold, size: 16)).foregroundColor(.white)
                    Spacer()
                }.frame(width: 300,height: 48).background(LinearGradient(colors: [Color(hex: "89216B"), Color(hex: "DA4453")], startPoint: .trailing, endPoint: .leading))
            }.padding(.bottom, 8).padding(.top, 16)
            Spacer().frame(height: 51)
            HStack{
                Text("Already a member?").font(.custom(SansPro.semibold, size: 16))
                Button(action: {
                    withAnimation{
                        model.signInOrCreateAccount.toggle()
                    }
                }){
                    Text("Sign in!").font(.custom(SansPro.semibold, size: 16))
                }
            }
        }
    }
    
    var body: some View {
        ZStack{
            VStack{
                Image("bg").resizable().scaledToFill().opacity(0.2).background(.black.opacity(0.7))
                
            }.frame(width: UIScreen.main.bounds.width).clipped().ignoresSafeArea()
            NavigationLink(destination: MainView().navigationBarHidden(true), isActive: $model.goNext){
                EmptyView()
            }
            if(model.signInOrCreateAccount){
                signUp
            }
            else{
                
                signIn
            }
        }
    }
}

struct SignIn_Previews: PreviewProvider {
    static var previews: some View {
        SignIn().environmentObject(loginViewModel())
    }
}

