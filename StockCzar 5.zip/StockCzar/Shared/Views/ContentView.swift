//
//  ContentView.swift
//  Shared
//
//  Created by Rathod Arjav on 13/08/22.
//

import SwiftUI
import FirebaseAuth
struct ContentView: View {
    var body: some View {
        NavigationView{
            if(Auth.auth().currentUser != nil){
                MainView().environmentObject(mainViewModel()).navigationBarHidden(true)
            }
            else{
            SignIn().environmentObject(loginViewModel()).navigationBarHidden(true)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
